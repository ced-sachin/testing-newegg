<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTScreenType',
  'IsAdvancedSearch' => 1,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'Multi-Touch Screen',
    1 => 'Non-Touch Screen',
    2 => 'Touch Screen',
  ),
) ?>