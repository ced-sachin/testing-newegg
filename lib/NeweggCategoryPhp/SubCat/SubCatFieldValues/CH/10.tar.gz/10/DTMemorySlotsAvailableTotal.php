<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTMemorySlotsAvailableTotal',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '0/1',
    1 => '0/2',
    2 => '0/4',
    3 => '0/6',
    4 => '1/2',
    5 => '1/3',
    6 => '1/4',
    7 => '2 total',
    8 => '2/4',
    9 => '3/4',
    10 => '3/6',
    11 => '4 total',
    12 => '6/8',
  ),
) ?>