<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTAudioChipset',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'Integrated',
    1 => 'Realtek ALC261',
    2 => 'Realtek ALC262',
    3 => 'Realtek ALC269',
    4 => 'Realtek ALC655',
    5 => 'Realtek ALC656',
    6 => 'Realtek ALC662',
    7 => 'Realtek ALC850',
    8 => 'Realtek ALC883',
    9 => 'Realtek ALC888',
    10 => 'Sound Blaster Live 5.1',
  ),
) ?>