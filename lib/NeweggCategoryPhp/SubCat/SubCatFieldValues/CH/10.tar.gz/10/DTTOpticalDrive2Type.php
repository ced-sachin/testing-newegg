<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTTOpticalDrive2Type',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '16X DVD-ROM',
    1 => 'CD-ROM',
    2 => 'DVD Super Multi',
    3 => 'DVD-ROM',
    4 => 'DVD/CD-RW Combo',
    5 => 'DVD±RW',
  ),
) ?>