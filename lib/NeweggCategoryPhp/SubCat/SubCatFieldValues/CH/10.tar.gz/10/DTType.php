<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTType',
  'IsAdvancedSearch' => 1,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'All-in-One PC',
    1 => 'Business Desktops & Workstations',
    2 => 'Gaming & Entertainment',
    3 => 'Nettop Computer',
    4 => 'Student / Home Office',
  ),
) ?>