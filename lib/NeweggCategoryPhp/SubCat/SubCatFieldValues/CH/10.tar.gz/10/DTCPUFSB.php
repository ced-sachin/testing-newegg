<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTCPUFSB',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '1066 MHz',
    1 => '1333 MHz',
    2 => '1600 MHz',
    3 => '333 MHz',
    4 => '400 MHz',
    5 => '533 MHz',
    6 => '600 MHz',
    7 => '667 MHz',
    8 => '800 MHz',
  ),
) ?>