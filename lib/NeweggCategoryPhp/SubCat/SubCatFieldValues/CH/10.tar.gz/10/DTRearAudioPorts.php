<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTRearAudioPorts',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '1 port',
    1 => '1x Headphone, 1x Microphone, 1x Line In',
    2 => '2 ports',
    3 => '3 ports',
    4 => '4 ports',
    5 => '5 ports',
    6 => '6 ports',
  ),
) ?>