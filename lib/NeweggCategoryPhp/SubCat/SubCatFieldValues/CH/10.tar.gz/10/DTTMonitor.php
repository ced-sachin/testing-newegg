<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTTMonitor',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 1,
  'PropertyValueList' => 
  array (
    0 => 'Monitor included',
    1 => 'Monitor not included',
  ),
) ?>