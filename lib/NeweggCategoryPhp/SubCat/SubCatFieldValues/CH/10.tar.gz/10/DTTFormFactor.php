<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTTFormFactor',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'DIMM 184-pin',
    1 => 'DIMM 240-pin',
    2 => 'DIMM 288-pin',
    3 => 'SoDIMM 200-pin',
    4 => 'SoDIMM 204-pin',
  ),
) ?>