<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTBluetooth',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'Bluetooth 2.0',
    1 => 'Bluetooth 2.1',
    2 => 'Bluetooth 3.0',
    3 => 'Bluetooth 4.0',
    4 => 'Bluetooth 4.1',
    5 => 'Bluetooth 4.2',
    6 => 'Bluetooth 5.0',
    7 => 'Yes',
  ),
) ?>