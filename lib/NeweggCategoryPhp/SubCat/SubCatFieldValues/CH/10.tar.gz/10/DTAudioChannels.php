<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTAudioChannels',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '2 channels',
    1 => '2.1 channels',
    2 => '5 channels',
    3 => '5.1 channels',
    4 => '6 channels',
    5 => '7 channels',
    6 => '7.1 channels',
    7 => '8 channels',
  ),
) ?>