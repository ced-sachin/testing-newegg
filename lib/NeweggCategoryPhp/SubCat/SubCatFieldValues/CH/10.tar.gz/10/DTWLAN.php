<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTWLAN',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '802.11a/b/g Wireless LAN',
    1 => '802.11a/b/g/n Wireless LAN',
    2 => '802.11ac Wireless LAN',
    3 => '802.11ad Wireless LAN',
    4 => '802.11ax Wireless LAN',
    5 => '802.11b/g Wireless LAN',
    6 => '802.11b/g/n Wireless LAN',
    7 => '802.11g Wireless LAN',
    8 => 'IEEE 802.11n',
  ),
) ?>