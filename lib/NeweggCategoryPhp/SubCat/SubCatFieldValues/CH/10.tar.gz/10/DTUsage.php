<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTUsage',
  'IsAdvancedSearch' => 1,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'Business',
    1 => 'Consumer',
    2 => 'Others',
  ),
) ?>