<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTTOpticalDrive2',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '16X DVD-ROM',
    1 => '16X DVD±RW Drive',
    2 => 'DVD-ROM',
  ),
) ?>