<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTMemorySlotAvailable',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '0',
    1 => '1',
    2 => '2',
    3 => '3',
    4 => '4',
    5 => '6',
    6 => '8',
  ),
) ?>