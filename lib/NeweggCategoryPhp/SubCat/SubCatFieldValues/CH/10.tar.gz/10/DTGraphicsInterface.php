<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTGraphicsInterface',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'AGP 4X/8X',
    1 => 'Integrated video',
    2 => 'PCI Express 2.0 x16',
    3 => 'PCI Express x16',
  ),
) ?>