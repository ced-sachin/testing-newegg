<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTSLICrossfire',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '2-Way',
    1 => '3-Way',
    2 => '4-Way',
  ),
) ?>