<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTHDDRPM',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '10000rpm',
    1 => '15000rpm',
    2 => '5400rpm',
    3 => '5900rpm',
    4 => '7200rpm',
  ),
) ?>