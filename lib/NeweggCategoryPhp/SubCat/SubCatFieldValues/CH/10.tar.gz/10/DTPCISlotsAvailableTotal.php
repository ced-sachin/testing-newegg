<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTPCISlotsAvailableTotal',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '3 PCI(total)',
    1 => '3/4',
    2 => '5 total',
  ),
) ?>