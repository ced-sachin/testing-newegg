<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTMemorySlotTotal',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => '1',
    1 => '12',
    2 => '16',
    3 => '2',
    4 => '4',
    5 => '6',
    6 => '8',
  ),
) ?>