<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTHDDInterface',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'PATA',
    1 => 'SAS',
    2 => 'SATA',
    3 => 'SATA II',
    4 => 'SATA III',
  ),
) ?>