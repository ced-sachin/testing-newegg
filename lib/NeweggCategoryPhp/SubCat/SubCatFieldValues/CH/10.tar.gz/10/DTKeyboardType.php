<?php return array (
  'SubcategoryID' => 10,
  'SubcategoryName' => 'DesktopPC',
  'PropertyName' => 'DTKeyboardType',
  'IsAdvancedSearch' => 0,
  'IsGroupBy' => 0,
  'IsRequired' => 0,
  'PropertyValueList' => 
  array (
    0 => 'PS/2 Keyboard',
    1 => 'Standard',
    2 => 'USB Keyboard',
    3 => 'Wired Keyboard',
    4 => 'Wireless Keyboard',
  ),
) ?>